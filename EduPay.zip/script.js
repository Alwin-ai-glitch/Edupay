const students=[
{
    id:1,
    name:"Peter Gumbo",
    country:"Zimbabwe",
    need:"$270/term",
    school:"Mutare Boys High",
    img:"pics/pic1.jpg",
    story:"Computer Science , Physics and Pure Mathematics AーLevel ーー Dreams to be Engineer"
   }
 ,
{
    id:2,
    name:"Tanatswa Nyamurundira",
    country:"Zimbabwe",
    need:"$230/term",
    school:"Sakubva 1 High",
    img:"pics/pic2.jpg",
    story:"A-level -> Maths, Biology, Chemistry ーー Wants to be doctor & engineer"
   },
{
    id:3,name:"Nigel T",
    country:"Zimbabwe",
    need:"$200/term",
    school:"St Mary High School Mutare",
    img:"pics/pic5.jpg",
    story:"Geography, Biology , Crop Science - Needs fees"
   },
{
    id:4,
    name:"Grace P Chigudu",
    country:"Zimbabwe",
    need:"$230/term",
    school:"Sakubva 1 High",
    img:"pics/pic3.jpg",
    story:"Maths, Biology, Chemistry ーー Wants to be doctor & engineer"
   },
{
    id:5,
    name:"Priviledge Chimuti",
    country:"Zimbabwe",
    need:"$200/term",
    school:"Sakubva 1 High",
    img:"pics/pic2.jpg",
    story:"Maths, Biology, Chemistry ーー Wants to be doctor & engineer"
   }      

];
localStorage.setItem('edu_students', JSON.stringify(students));